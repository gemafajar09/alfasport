<?php
require 'vendor/autoload.php';

// this file (index.php) is entry point for all code
require_once "config.php";
require_once "restapi-helper.php";
require_once "db.php";
