<?php
// load .env file for configuration
Dotenv\Dotenv::createImmutable(__DIR__)->load();