<?php
include "../../../config/koneksi.php";

$json = file_get_contents('php://input');
$_POST = json_decode($json,true);

$hapus = $con->query("DELETE FROM toko WHERE id_toko = '$_POST[id_toko]'");
if($hapus == TRUE)
{
    echo json_encode('SUCCESS');
}
else
{
    echo json_encode('ERROR');
}