<?php

include "../../config/koneksi.php";
if(isset($_POST['simpan']))
{
    $ukuran = $_POST['ukuran'];
    $jumlah = $_POST['jumlah'];
    $barcode = $_POST['barcode'];
    $tanggal = date('Y-m-d');
    foreach ($ukuran as $i => $a) {
        // echo $ukuran[$i];
        $con->query("INSERT INTO tb_gudang_detail (id,id_ukuran,jumlah,barcode,tanggal) VALUES ('$_POST[id]','$ukuran[$i]','$jumlah[$i]','$barcode[$i]','$tanggal')");
        
    }
    
    echo "
    <script>
        window.location='../../entry_gudang.html'
    </script>
    ";
} 